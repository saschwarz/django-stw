Django application for inserting Shrink The Web (http://www.shrinktheweb.com/) images into templates.

Contains two templatetags providing thin wrapper around the STW api:
http://www.shrinktheweb.com/content/shrinktheweb-pagepix-documentation.html

This application has been tested using django 1.1.1, 1.2, and 1.3

Includes an example view/template for demo purposes. See INSTALL.txt for details.
